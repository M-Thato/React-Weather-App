// Import all necessary dependecies, functions or styles
import HomeComponent from "./modules/Home";

// Render Home Page
function App() {
    return (<HomeComponent/>);
}
// Export The Component
export default App;
export function handleHomeClick() {
    window.location.reload();
}